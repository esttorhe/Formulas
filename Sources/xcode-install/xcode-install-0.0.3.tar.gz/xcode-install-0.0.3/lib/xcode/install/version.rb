module XcodeInstall
	VERSION = "0.0.3"
end
